-- COPY_ONLY leaves the normal SQL backup chain unchanged.
DECLARE @backupDir nvarchar(4000) = CONVERT(nvarchar(4000), SERVERPROPERTY('InstanceDefaultBackupPath'));
IF @backupDir IS NULL THROW 50000, 'SQL Server did not return its default backup directory.', 1;
DECLARE @file nvarchar(4000) = @backupDir + N'\HotelIoT_Rebuild_' +
    CONVERT(char(8), GETDATE(), 112) + N'_' + REPLACE(CONVERT(char(8), GETDATE(), 108), ':', '') + N'.bak';
BACKUP DATABASE [HotelIoT] TO DISK = @file WITH COPY_ONLY, CHECKSUM;
RESTORE VERIFYONLY FROM DISK = @file WITH CHECKSUM;
SELECT @file AS BackupFile;
