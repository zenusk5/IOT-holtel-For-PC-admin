SET NOCOUNT ON;
IF DB_ID(N'HotelIoT') IS NULL
BEGIN
    CREATE DATABASE HotelIoT COLLATE Latin1_General_100_CI_AI_SC;
END;
GO
USE HotelIoT;
GO
SET XACT_ABORT ON;
BEGIN TRANSACTION;
IF OBJECT_ID(N'dbo.Users',N'U') IS NULL
CREATE TABLE dbo.Users (
    UserId int IDENTITY(1,1) PRIMARY KEY,
    Username nvarchar(64) NOT NULL UNIQUE,
    PasswordHash varchar(64) NOT NULL,
    Role nvarchar(20) NOT NULL CONSTRAINT DF_Users_Role DEFAULT N'Staff',
    IsActive bit NOT NULL CONSTRAINT DF_Users_Active DEFAULT 1,
    CreatedAt datetime2(0) NOT NULL CONSTRAINT DF_Users_Created DEFAULT SYSDATETIME()
);
IF OBJECT_ID(N'dbo.RFIDCards',N'U') IS NULL
CREATE TABLE dbo.RFIDCards (
    CardId int IDENTITY(1,1) PRIMARY KEY,
    UID nvarchar(64) NOT NULL UNIQUE,
    CardHolder nvarchar(160) NOT NULL,
    IsActive bit NOT NULL CONSTRAINT DF_RFIDCards_Active DEFAULT 1,
    ValidTo datetime2(0) NULL,
    CreatedAt datetime2(0) NOT NULL CONSTRAINT DF_RFIDCards_Created DEFAULT SYSDATETIME()
);
IF OBJECT_ID(N'dbo.RFIDLogs',N'U') IS NULL
CREATE TABLE dbo.RFIDLogs (
    LogId int IDENTITY(1,1) PRIMARY KEY,
    UID nvarchar(64) NULL,
    AccessTime datetime2(0) NOT NULL CONSTRAINT DF_RFIDLogs_Time DEFAULT SYSDATETIME(),
    AccessStatus nvarchar(32) NOT NULL,
    DeviceId nvarchar(64) NULL,
    Notes nvarchar(1000) NULL,
    Source nvarchar(64) NULL
);
IF OBJECT_ID(N'dbo.DeviceLogs',N'U') IS NULL
CREATE TABLE dbo.DeviceLogs (
    LogId int IDENTITY(1,1) PRIMARY KEY,
    DeviceName nvarchar(64) NOT NULL,
    Action nvarchar(64) NOT NULL,
    TriggerSource nvarchar(64) NULL,
    Details nvarchar(1000) NULL,
    LogTime datetime2(0) NOT NULL CONSTRAINT DF_DeviceLogs_Time DEFAULT SYSDATETIME()
);
IF OBJECT_ID(N'dbo.SystemEvents',N'U') IS NULL
CREATE TABLE dbo.SystemEvents (
    EventId int IDENTITY(1,1) PRIMARY KEY,
    EventTime datetime2(0) NOT NULL CONSTRAINT DF_SystemEvents_Time DEFAULT SYSDATETIME(),
    EventType nvarchar(80) NOT NULL,
    Description nvarchar(2000) NULL,
    Severity nvarchar(24) NOT NULL CONSTRAINT DF_SystemEvents_Severity DEFAULT N'INFO'
);
IF OBJECT_ID(N'dbo.DeviceStatus',N'U') IS NULL
CREATE TABLE dbo.DeviceStatus (
    DeviceId nvarchar(64) PRIMARY KEY,
    RoomName nvarchar(80) NOT NULL CONSTRAINT DF_DeviceStatus_Room DEFAULT N'Phòng 101',
    DoorStatus nvarchar(20) NULL,
    RoofStatus nvarchar(20) NULL,
    RainStatus nvarchar(20) NULL,
    LedStatus nvarchar(20) NULL,
    LastUpdated datetime2(0) NOT NULL CONSTRAINT DF_DeviceStatus_Time DEFAULT SYSDATETIME()
);
IF NOT EXISTS(SELECT 1 FROM dbo.Users WHERE Username=N'admin')
INSERT dbo.Users(Username,PasswordHash,Role)
VALUES(N'admin','240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9',N'Admin');
IF NOT EXISTS(SELECT 1 FROM dbo.DeviceStatus WHERE DeviceId=N'RPI_ROOM_101')
INSERT dbo.DeviceStatus(DeviceId,DoorStatus,RoofStatus,RainStatus,LedStatus)
VALUES(N'RPI_ROOM_101',N'CLOSED',N'OPEN',N'NO_RAIN',N'OFF');
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name=N'IX_RFIDLogs_Time' AND object_id=OBJECT_ID(N'dbo.RFIDLogs'))
CREATE INDEX IX_RFIDLogs_Time ON dbo.RFIDLogs(AccessTime DESC) INCLUDE(UID,AccessStatus,DeviceId);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name=N'IX_DeviceLogs_Time' AND object_id=OBJECT_ID(N'dbo.DeviceLogs'))
CREATE INDEX IX_DeviceLogs_Time ON dbo.DeviceLogs(LogTime DESC);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name=N'IX_SystemEvents_Time' AND object_id=OBJECT_ID(N'dbo.SystemEvents'))
CREATE INDEX IX_SystemEvents_Time ON dbo.SystemEvents(EventTime DESC);
COMMIT;
SELECT N'HotelIoT schema ready' AS Result;
GO
