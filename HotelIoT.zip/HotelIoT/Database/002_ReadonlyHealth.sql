USE HotelIoT;
SET NOCOUNT ON;
SELECT DB_NAME() AS DatabaseName,@@SERVERNAME AS ServerName;
SELECT N'RFIDCards' AS Entity,COUNT_BIG(*) AS Rows FROM dbo.RFIDCards
UNION ALL SELECT N'RFIDLogs',COUNT_BIG(*) FROM dbo.RFIDLogs
UNION ALL SELECT N'DeviceLogs',COUNT_BIG(*) FROM dbo.DeviceLogs
UNION ALL SELECT N'SystemEvents',COUNT_BIG(*) FROM dbo.SystemEvents;
SELECT DeviceId,RoomName,DoorStatus,RoofStatus,RainStatus,LedStatus,LastUpdated FROM dbo.DeviceStatus;
