const AUTH_TOKEN = "Bearer HotelIoTToken2026";
let currentTab = "tabCards";
let statusInterval = null;
let tabInterval = null;

// KIEM TRA TRANG THAI KHOA KHI MO TRANG
document.addEventListener("DOMContentLoaded", () => {
    const isUnlocked = sessionStorage.getItem("hotel_iot_unlocked") === "true";
    if (isUnlocked) {
        showDashboard();
    } else {
        showGateScreen();
    }
});

// XU LY XAC THUC MA KEY
async function handleGateUnlock(e) {
    e.preventDefault();
    const keyInput = document.getElementById("gateKeyInput").value.trim();
    const errorMsg = document.getElementById("gateErrorMsg");

    // Chap nhan ma key 2026 hoac mat khau admin
    if (keyInput === "2026" || keyInput === "admin123" || keyInput === "123" || keyInput === "admin" || keyInput === "Admin@123") {
        sessionStorage.setItem("hotel_iot_unlocked", "true");
        showToast("Mo khoa thanh cong! Chao mung Admin.", "success");
        showDashboard();
        return;
    }

    // Neu nhap khac, xac thuc qua backend
    try {
        const res = await fetch("/api/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username: "admin", password: keyInput })
        });
        const data = await res.json();
        if (res.ok && data.status === "success") {
            sessionStorage.setItem("hotel_iot_unlocked", "true");
            showToast("Mo khoa thanh cong qua he thong!", "success");
            showDashboard();
        } else {
            errorMsg.innerText = "Ma Key khong hop le! Vui long kiem tra lai.";
            document.getElementById("gateKeyInput").value = "";
            document.getElementById("gateKeyInput").focus();
        }
    } catch (err) {
        errorMsg.innerText = "Sai ma Key! (Goi y: 2026)";
    }
}

function showGateScreen() {
    document.getElementById("gateScreen").style.display = "flex";
    document.getElementById("mainDashboard").style.display = "none";
    document.getElementById("gateKeyInput").value = "";
    document.getElementById("gateErrorMsg").innerText = "";
    document.getElementById("gateKeyInput").focus();
    if (statusInterval) clearInterval(statusInterval);
    if (tabInterval) clearInterval(tabInterval);
}

function showDashboard() {
    document.getElementById("gateScreen").style.display = "none";
    document.getElementById("mainDashboard").style.display = "block";

    // Khoi chay cap nhat du lieu
    updateStatus();
    loadCurrentTabData();
    if (!statusInterval) statusInterval = setInterval(updateStatus, 2000);
    if (!tabInterval) tabInterval = setInterval(loadCurrentTabData, 5000);
}

function lockSystem() {
    sessionStorage.removeItem("hotel_iot_unlocked");
    showToast("Da khoa he thong thanh cong.", "warn");
    showGateScreen();
}

function showToast(msg, type = "success") {
    const container = document.getElementById("toastContainer");
    if (!container) return;
    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    toast.innerText = msg;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 2600);
}

// POLLING TRANG THAI THIET BI
async function updateStatus() {
    try {
        const res = await fetch("/api/status");
        if (!res.ok) throw new Error();
        const d = await res.json();

        const elDoor = document.getElementById("valDoor");
        if (elDoor) {
            elDoor.innerText = d.door;
            elDoor.className = "card-value " + (d.door === "OPEN" ? "val-open" : "val-closed");
            document.getElementById("subDoor").innerText = d.door === "OPEN" ? "Cua dang mo (giu nguyen lenh)" : "Chot cua dang khoa an toan";
        }

        const elRoof = document.getElementById("valRoof");
        if (elRoof) {
            elRoof.innerText = d.roof;
            elRoof.className = "card-value " + (d.roof === "OPEN" ? "val-open" : "val-closed");
            document.getElementById("subRoof").innerText = d.roof === "OPEN" ? "Mai che dang mo thoang khi" : "Mai che da dong che chan";
        }

        const elLed = document.getElementById("valLed");
        if (elLed) {
            elLed.innerText = d.led;
            document.getElementById("badgeLed").innerText = d.led;
            document.getElementById("subLed").innerText = d.led === "OFF" ? "Den phong da tat" : "Den phong dang sang (" + d.led + ")";
        }

        const elRain = document.getElementById("valRain");
        if (elRain) {
            elRain.innerText = d.rain ? "CO MUA (YES)" : "KHO RAO (NO)";
            elRain.style.color = d.rain ? "var(--red)" : "var(--cyan)";
            document.getElementById("subOled").innerText = "OLED: " + (d.oled || "HOTEL ROOM 101");
        }

        const dotSql = document.getElementById("dotSql");
        const textSql = document.getElementById("textSql");
        if (dotSql && textSql) {
            dotSql.className = "status-dot " + (d.sql_connected ? "dot-green" : "dot-amber");
            textSql.innerText = d.sql_connected ? "SQL: Online" : "SQL: Offline (Cache)";
        }

        const dotPi = document.getElementById("dotPi");
        const textPi = document.getElementById("textPi");
        if (dotPi && textPi) {
            dotPi.className = "status-dot dot-green";
            textPi.innerText = "RPI: Online";
        }
    } catch (e) {
        const dotPi = document.getElementById("dotPi");
        const textPi = document.getElementById("textPi");
        if (dotPi && textPi) {
            dotPi.className = "status-dot dot-red";
            textPi.innerText = "RPI: Offline";
        }
    }
}

// DIEU KHIEN THIET BI (TU DO KHONG GIOI HAN)
async function sendCommand(command, btn) {
    if (btn) {
        btn.disabled = true;
        setTimeout(() => { btn.disabled = false; }, 700);
    }
    try {
        const res = await fetch("/api/control", {
            method: "POST",
            headers: { "Content-Type": "application/json", "Authorization": AUTH_TOKEN },
            body: JSON.stringify({ command: command, cmd_id: "WEB_" + Date.now() })
        });
        const data = await res.json();
        if (data.status === "success") {
            showToast("Thuc thi: " + command, "success");
            updateStatus();
        } else {
            showToast("Lenh bi tu choi!", "warn");
        }
    } catch (e) {
        showToast("Loi gui lenh!", "error");
    }
}

// QUAN LY TABS & DU LIEU
function switchTab(evt, tabId) {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
    evt.currentTarget.classList.add("active");
    const target = document.getElementById(tabId);
    if (target) target.classList.add("active");
    currentTab = tabId;
    loadCurrentTabData();
}

function loadCurrentTabData() {
    if (currentTab === "tabCards") loadCards();
    else if (currentTab === "tabLogs") loadLogs();
    else if (currentTab === "tabDeviceLogs") loadDeviceLogs();
    else if (currentTab === "tabEvents") loadEvents();
}

async function loadCards() {
    try {
        const res = await fetch("/api/cards", { headers: { "Authorization": AUTH_TOKEN } });
        const cards = await res.json();
        const tbody = document.getElementById("tbodyCards");
        if (!tbody) return;
        if (!cards || cards.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="empty-state">Chua co the RFID nao trong he thong.</td></tr>`;
            return;
        }
        tbody.innerHTML = cards.map(c => `
            <tr>
                <td>#${c.id}</td>
                <td><b>${c.uid}</b></td>
                <td>${c.holder}</td>
                <td><span class="status-pill ${c.active ? 'pill-green' : 'pill-red'}">${c.active ? 'HOAT DONG' : 'DA KHOA'}</span></td>
                <td>
                    <button class="btn btn-slate" style="padding: 4px 10px; font-size: 11px;" onclick="toggleCard('${c.uid}', ${!c.active})">
                        ${c.active ? 'Khoa' : 'Mo'}
                    </button>
                    <button class="btn btn-red" style="padding: 4px 10px; font-size: 11px; margin-left: 6px;" onclick="deleteCard('${c.uid}')">Xoa</button>
                </td>
            </tr>
        `).join("");
    } catch (e) {}
}

async function addCard() {
    const uid = document.getElementById("newCardUid").value.trim().toUpperCase();
    const holder = document.getElementById("newCardHolder").value.trim();
    if (!uid || !holder) {
        showToast("Vui long nhap du Ma UID va Chu the!", "warn");
        return;
    }
    try {
        const res = await fetch("/api/cards", {
            method: "POST",
            headers: { "Content-Type": "application/json", "Authorization": AUTH_TOKEN },
            body: JSON.stringify({ uid: uid, holder: holder })
        });
        if (res.ok) {
            document.getElementById("newCardUid").value = "";
            document.getElementById("newCardHolder").value = "";
            showToast("Them the thanh cong!", "success");
            loadCards();
        }
    } catch (e) {}
}

async function toggleCard(uid, active) {
    try {
        const res = await fetch("/api/cards", {
            method: "PUT",
            headers: { "Content-Type": "application/json", "Authorization": AUTH_TOKEN },
            body: JSON.stringify({ uid: uid, active: active })
        });
        if (res.ok) {
            showToast(active ? "Da kich hoat the!" : "Da vo hieu hoa the!", "success");
            loadCards();
        }
    } catch (e) {}
}

async function deleteCard(uid) {
    if (!confirm(`Xac nhan xoa the UID: ${uid}?`)) return;
    try {
        const res = await fetch(`/api/cards?uid=${encodeURIComponent(uid)}`, {
            method: "DELETE",
            headers: { "Authorization": AUTH_TOKEN }
        });
        if (res.ok) {
            showToast("Da xoa the!", "warn");
            loadCards();
        }
    } catch (e) {}
}

async function loadLogs() {
    const uid = document.getElementById("filterUid") ? document.getElementById("filterUid").value.trim() : "";
    const status = document.getElementById("filterStatus") ? document.getElementById("filterStatus").value : "";
    try {
        const res = await fetch(`/api/logs?uid=${encodeURIComponent(uid)}&status=${encodeURIComponent(status)}`, {
            headers: { "Authorization": AUTH_TOKEN }
        });
        const logs = await res.json();
        const tbody = document.getElementById("tbodyLogs");
        if (!tbody) return;
        if (!logs || logs.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="empty-state">Khong co nhat ky quet the phu hop.</td></tr>`;
            return;
        }
        tbody.innerHTML = logs.map(l => `
            <tr>
                <td>#${l.id}</td>
                <td style="color: var(--text-secondary);">${l.time}</td>
                <td><b>${l.uid}</b></td>
                <td><span class="status-pill ${l.status === 'ACCESS' ? 'pill-green' : 'pill-red'}">${l.status}</span></td>
                <td>${l.notes || ''}</td>
            </tr>
        `).join("");
    } catch (e) {}
}

async function loadDeviceLogs() {
    try {
        const res = await fetch("/api/device-logs", { headers: { "Authorization": AUTH_TOKEN } });
        const logs = await res.json();
        const tbody = document.getElementById("tbodyDeviceLogs");
        if (!tbody) return;
        if (!logs || logs.length === 0) {
            tbody.innerHTML = `<tr><td colspan="6" class="empty-state">Chua co lich su thiet bi.</td></tr>`;
            return;
        }
        tbody.innerHTML = logs.map(d => `
            <tr>
                <td>#${d.id}</td>
                <td style="color: var(--text-secondary);">${d.time}</td>
                <td><b>${d.device}</b></td>
                <td><span class="status-pill pill-blue">${d.action}</span></td>
                <td>${d.source}</td>
                <td>${d.details || ''}</td>
            </tr>
        `).join("");
    } catch (e) {}
}

async function loadEvents() {
    try {
        const res = await fetch("/api/events", { headers: { "Authorization": AUTH_TOKEN } });
        const evs = await res.json();
        const tbody = document.getElementById("tbodyEvents");
        if (!tbody) return;
        if (!evs || evs.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="empty-state">Chua co su kien he thong.</td></tr>`;
            return;
        }
        tbody.innerHTML = evs.map(e => `
            <tr>
                <td>#${e.id}</td>
                <td style="color: var(--text-secondary);">${e.time}</td>
                <td><b>${e.type}</b></td>
                <td>${e.desc}</td>
                <td><span class="status-pill ${e.severity === 'WARNING' ? 'pill-red' : 'pill-blue'}">${e.severity}</span></td>
            </tr>
        `).join("");
    } catch (e) {}
}
