# Hotel IoT / Raspberry hotel project

This is the independent hotel project rooted at D:\HotelIoT.

- Desktop source: Desktop/HotelIoT.Desktop; solution: Desktop/LongVan.HotelIoT.sln.
- Pi source: PiServer; restored Flask website: Website; SQL schema and backup: Database.
- Image resources live inside Assets and Desktop/HotelIoT.Desktop/Assets.
- Keep all new hotel files inside this project. Use paths relative to the project where possible.
- private contains credentials and recovery data. Do not print credentials, commit private, or put secrets in Publish.
- The Pi is 192.168.1.28; existing SQL instance is .\TUAN, database HotelIoT. Do not change other databases.
- hotel-iot, pigpiod and mosquitto already run as services on the Pi. Do not start a second main.py process.
- Device actions can move real hardware. Use read-only status checks for routine build or visual changes.
- Build only the needed .NET project; do not run card CRUD tests for simple UI/path changes.
- private/setup-history records one-time setup. Read its notes before considering reuse.
- Read README_VI.md for runtime, credentials-file location and hardware limitations.
