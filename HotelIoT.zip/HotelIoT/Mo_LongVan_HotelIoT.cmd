@echo off
start "" "%~dp0Publish\LongVan.HotelIoT.exe"
