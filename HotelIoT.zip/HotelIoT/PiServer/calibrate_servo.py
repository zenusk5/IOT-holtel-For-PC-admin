# -*- coding: utf-8 -*-
import sys
import time

try:
    import pigpio
except ImportError:
    print("Loi: Chua cai dat thu vien pigpio! Chay: sudo apt install python3-pigpio")
    sys.exit(1)

PIN_DOOR = 23  # Servo Cua (GPIO 23 - Pin 16 vat ly)
PIN_ROOF = 22  # Servo Mai che (GPIO 22 - Pin 15 vat ly)

pi = pigpio.pi()
if not pi.connected:
    print("Loi: pigpiod chua chay! Chay lenh: sudo systemctl start pigpiod")
    sys.exit(1)


def pulse_to_deg(pulse):
    """Quy doi do rong xung PWM (500 - 2500us) sang goc do (0 - 180 do)"""
    deg = (pulse - 500) * 180.0 / 2000.0
    return round(max(0.0, min(180.0, deg)), 1)


def deg_to_pulse(deg):
    """Quy doi goc do (0 - 180 do) sang do rong xung PWM (500 - 2500us)"""
    pulse = 500.0 + (deg * 2000.0 / 180.0)
    return int(max(500, min(2500, round(pulse))))


def move_servo(pin, pulse, hold=0.55):
    pulse = max(500, min(2500, int(pulse)))
    deg = pulse_to_deg(pulse)
    print(f"--> Dang cap xung {pulse}us (~{deg} do) toi GPIO {pin}...")
    pi.set_servo_pulsewidth(pin, pulse)
    time.sleep(hold)
    pi.set_servo_pulsewidth(pin, 0)  # Ngat xung chong nong servo
    print(f"--> Da ngat xung. Servo xac lap goc hien tai: {deg} do ({pulse}us)")
    return pulse
def main():
    state = {
        PIN_DOOR: {"name": "CUA PHONG (GPIO 23)", "pulse": 650},
        PIN_ROOF: {"name": "MAI CHE (GPIO 22)", "pulse": 650},
    }
    curr_pin = PIN_DOOR

    print("=" * 65)
    print("      CONG CU KIEM TRA & CAN CHINH GOC QUAY SERVO SG90")
    print("=" * 65)
    print("Lenh dieu khien:")
    print("  1              : Chon Servo CUA (GPIO 23)")
    print("  2              : Chon Servo MAI CHE (GPIO 22)")
    print("  g              : Xem GOC HIEN TAI & XUNG cua ca 2 servo")
    print("  <so>           : Nhap xung PWM truc tiep (vi du: 650, 1500, 2100)")
    print("  d <goc>        : Quay theo GOC DO (vi du: d 90, d 45, d 144)")
    print("  + / -          : Tang / Giam 50us xung hien tai")
    print("  c              : Test nhanh muc DONG mac dinh (650us ~ 13.5 do)")
    print("  o              : Test nhanh muc MO 90 DO (1500us ~ 90.0 do)")
    print("  m              : Test nhanh muc MO RONG (2100us ~ 144.0 do)")
    print("  q              : Thoat chuong trinh")
    print("=" * 65)

    while True:
        try:
            p = state[curr_pin]["pulse"]
            d = pulse_to_deg(p)
            name = state[curr_pin]["name"]

            cmd = input(f"\n[{name} | Goc: {d} do ({p}us)] > ").strip().lower()
            if not cmd:
                continue

            if cmd == "q":
                break
            elif cmd == "1":
                curr_pin = PIN_DOOR
                print(f"Da chuyen sang: {state[curr_pin]['name']}")
            elif cmd == "2":
                curr_pin = PIN_ROOF
                print(f"Da chuyen sang: {state[curr_pin]['name']}")
            elif cmd == "g":
                print("-" * 50)
                print("TRANG THAI GOC QUAY HIEN TAI:")
                for pin, data in state.items():
                    pulse = data["pulse"]
                    deg = pulse_to_deg(pulse)
                    print(f"  * {data['name']}: {deg} do (Xung: {pulse}us)")
                print("-" * 50)
            elif cmd.startswith("d "):
                deg_val = float(cmd.split()[1])
                pulse_target = deg_to_pulse(deg_val)
                state[curr_pin]["pulse"] = move_servo(curr_pin, pulse_target)
            elif cmd == "c":
                state[curr_pin]["pulse"] = move_servo(curr_pin, 650)
            elif cmd == "o":
                state[curr_pin]["pulse"] = move_servo(curr_pin, 1500)
            elif cmd == "m":
                state[curr_pin]["pulse"] = move_servo(curr_pin, 2100)
            elif cmd.startswith("+"):
                delta = int(cmd[1:]) if len(cmd) > 1 else 50
                state[curr_pin]["pulse"] = move_servo(curr_pin, p + delta)
            elif cmd.startswith("-"):
                delta = int(cmd[1:]) if len(cmd) > 1 else 50
                state[curr_pin]["pulse"] = move_servo(curr_pin, p - delta)
            elif cmd.isdigit():
                state[curr_pin]["pulse"] = move_servo(curr_pin, int(cmd))
            else:
                print("Lenh khong hop le! Go 'g' de xem goc, 'd 90' de quay 90 do.")
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"Loi: {e}")

    pi.set_servo_pulsewidth(PIN_DOOR, 0)
    pi.set_servo_pulsewidth(PIN_ROOF, 0)
    pi.stop()
    print("\nDa ngat xung an toan va thoat.")


if __name__ == "__main__":
    main()
